python WriteSharedFormula.py

